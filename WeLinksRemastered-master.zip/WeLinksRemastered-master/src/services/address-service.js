import React from 'react';

export const AddressContext = React.createContext({
    addresses: [],
    sync: ()=>{}

})
export default function AddressProvider(){

}